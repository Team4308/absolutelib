package ca.team4308.absolutelib.math.trajectories;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ca.team4308.absolutelib.math.trajectories.shooter.ShotLookupTable;
import edu.wpi.first.math.util.Units;

/**
 * Input parameters for a trajectory shot calculation.
 * Immutable data class representing the shot setup.
 * 
 * <h2>Obstacle-Aware Shots</h2>
 * <pre>
 * ObstacleConfig hub = ObstacleConfig.builder()
 *     .position(4.03, 4.0).baseSize(1.19).wallHeight(1.83)
 *     .upperStructureHeight(0.41).openingDiameter(1.06).build();
 * 
 * ShotInput input = ShotInput.builder()
 *     .shooterPositionMeters(1.0, 2.0, 0.5)
 *     .targetPositionMeters(5.0, 5.0, 2.5)
 *     .addObstacle(hub)
 *     .collisionCheckEnabled(true)
 *     .preferredArcHeightMeters(2.5)  // Bias toward this apex height
 *     .build();
 * </pre>
 */

public class ShotInput {

    /**
     * Shot selection preference when multiple candidates are available.
     */

    public enum ShotPreference {

        /** Automatically select best overall candidate */

        AUTO,

        /** Prefer fastest time of flight (low arc) */

        FASTEST,

        /** Prefer highest clearance (high arc) */

        HIGH_CLEARANCE,

        /** Prefer most stable/consistent shot */

        MOST_STABLE,

        /** Prefer minimum velocity (easiest on mechanism) */

        MIN_VELOCITY,

        /** Prefer trajectory closest to dead center of target. */
        MOST_ACCURATE
    }

    private final double shooterX;
    private final double shooterY;
    private final double shooterZ;

    private final double shooterYaw;

    private final double targetX;
    private final double targetY;
    private final double targetZ;

    private final double targetRadius;

    private final double robotVx;
    private final double robotVy;
    private final double robotOmegaRadPerSec;
    private final double shooterRadiusMeters;

    private final boolean includeAirResistance;

    private final ShotPreference shotPreference;
    private final int maxCandidates;
    private final double minPitchDegrees;
    private final double maxPitchDegrees;
    private final double minVelocityMps;
    private final double maxVelocityMps;
    private final double angleStepDegrees;
    private final double minArcHeightMeters;

    private final List<ObstacleConfig> obstacles;
    private final boolean collisionCheckEnabled;
    private final double preferredArcHeightMeters;
    private final double arcBiasStrength;

    private final ShotLookupTable map;

    /**
     * Full constructor with all new parameters.
     */

    private ShotInput(double shooterX, double shooterY, double shooterZ,
                      double shooterYaw,
                      double targetX, double targetY, double targetZ,
                      double targetRadius,
                      double robotVx, double robotVy,
                      double robotOmegaRadPerSec, double shooterRadiusMeters,
                      boolean includeAirResistance,
                      ShotPreference shotPreference, int maxCandidates,
                      double minPitchDegrees, double maxPitchDegrees,
                      double minVelocityMps, double maxVelocityMps,
                      double angleStepDegrees, double minArcHeightMeters,
                      List<ObstacleConfig> obstacles, boolean collisionCheckEnabled,
                      double preferredArcHeightMeters, double arcBiasStrength,
                      ShotLookupTable map) {
        this.shooterX = shooterX;
        this.shooterY = shooterY;
        this.shooterZ = shooterZ;
        this.shooterYaw = shooterYaw;
        this.targetX = targetX;
        this.targetY = targetY;
        this.targetZ = targetZ;
        this.targetRadius = targetRadius;
        this.robotVx = robotVx;
        this.robotVy = robotVy;
        this.robotOmegaRadPerSec = robotOmegaRadPerSec;
        this.shooterRadiusMeters = shooterRadiusMeters;
        this.includeAirResistance = includeAirResistance;
        this.shotPreference = shotPreference;
        this.maxCandidates = maxCandidates;
        this.minPitchDegrees = minPitchDegrees;
        this.maxPitchDegrees = maxPitchDegrees;
        this.minVelocityMps = minVelocityMps;
        this.maxVelocityMps = maxVelocityMps;
        this.angleStepDegrees = angleStepDegrees;
        this.minArcHeightMeters = minArcHeightMeters;
        this.obstacles = obstacles != null ? Collections.unmodifiableList(new ArrayList<>(obstacles)) : Collections.emptyList();
        this.collisionCheckEnabled = collisionCheckEnabled;
        this.preferredArcHeightMeters = preferredArcHeightMeters;
        this.arcBiasStrength = arcBiasStrength;
        this.map = map;
    }

    /**
     * Builder for fluent construction with unit flexibility.
     */

    public static class Builder {
        private double shooterX = 0;
        private double shooterY = 0;
        private double shooterZ = 0;
        private double shooterYaw = 0;
        private double targetX = 0;
        private double targetY = 0;
        private double targetZ = 0;
        private double targetRadius = 0.15;
        private double robotVx = 0;
        private double robotVy = 0;
        private double robotOmegaRadPerSec = 0;
        private double shooterRadiusMeters = 0;
        private boolean includeAirResistance = true;

        private ShotPreference shotPreference = ShotPreference.AUTO;
        private int maxCandidates = 50;
        private double minPitchDegrees = 5;
        private double maxPitchDegrees = 85;
        private double minVelocityMps = 5;
        private double maxVelocityMps = 50;
        private double angleStepDegrees = 1.0;
        private double minArcHeightMeters = 0.0;

        private final List<ObstacleConfig> obstacles = new ArrayList<>();
        private boolean collisionCheckEnabled = false;
        private double preferredArcHeightMeters = 0.0;
        private double arcBiasStrength = 0.5;
        private ShotLookupTable map = null;

        /**
         * Sets shooter position in meters.
         */

        public Builder shooterPositionMeters(double x, double y, double z) {
            this.shooterX = x;
            this.shooterY = y;
            this.shooterZ = z;
            return this;
        }

        /**
         * Sets shooter position in inches.
         */

        public Builder shooterPositionInches(double x, double y, double z) {
            this.shooterX = Units.inchesToMeters(x);
            this.shooterY = Units.inchesToMeters(y);
            this.shooterZ = Units.inchesToMeters(z);
            return this;
        }

        /**
         * Sets shooter position in feet.
         */

        public Builder shooterPositionFeet(double x, double y, double z) {
            this.shooterX = Units.feetToMeters(x);
            this.shooterY = Units.feetToMeters(y);
            this.shooterZ = Units.feetToMeters(z);
            return this;
        }

        /**
         * Sets shooter yaw in radians.
         */

        public Builder shooterYawRadians(double yaw) {
            this.shooterYaw = yaw;
            return this;
        }

        /**
         * Sets shooter yaw in degrees.
         */

        public Builder shooterYawDegrees(double yaw) {
            this.shooterYaw = Math.toRadians(yaw);
            return this;
        }

        /**
         * Sets target position in meters.
         */

        public Builder targetPositionMeters(double x, double y, double z) {
            this.targetX = x;
            this.targetY = y;
            this.targetZ = z;
            return this;
        }

        /**
         * Sets target position in inches.
         */

        public Builder targetPositionInches(double x, double y, double z) {
            this.targetX = Units.inchesToMeters(x);
            this.targetY = Units.inchesToMeters(y);
            this.targetZ = Units.inchesToMeters(z);
            return this;
        }

        /**
         * Sets target position in feet.
         */

        public Builder targetPositionFeet(double x, double y, double z) {
            this.targetX = Units.feetToMeters(x);
            this.targetY = Units.feetToMeters(y);
            this.targetZ = Units.feetToMeters(z);
            return this;
        }

        /**
         * Sets target acceptance radius in meters.
         */

        public Builder targetRadiusMeters(double radius) {
            this.targetRadius = radius;
            return this;
        }

        /**
         * Sets target acceptance radius in inches.
         */

        public Builder targetRadiusInches(double radius) {
            this.targetRadius = Units.inchesToMeters(radius);
            return this;
        }

        /**
         * Sets robot velocity in meters/sec (field-relative) and angular velocity.
         */
        public Builder robotVelocity(double vx, double vy, double omegaRadPerSec, double shooterRadiusM) {
            this.robotVx = vx;
            this.robotVy = vy;
            this.robotOmegaRadPerSec = omegaRadPerSec;
            this.shooterRadiusMeters = shooterRadiusM;
            return this;
        }
        
        /**
         * Sets robot velocity in meters/sec (field-relative) without angular velocity.
         */
        public Builder robotVelocity(double vx, double vy) {
            this.robotVx = vx;
            this.robotVy = vy;
            this.robotOmegaRadPerSec = 0;
            this.shooterRadiusMeters = 0;
            return this;
        }

        /**
         * Sets whether to include air resistance.
         */

        public Builder includeAirResistance(boolean include) {
            this.includeAirResistance = include;
            return this;
        }

        /**
         * Sets the shot preference for candidate selection.
         * This replaces the old preferHighArc boolean.
         */

        public Builder shotPreference(ShotPreference preference) {
            this.shotPreference = preference;
            return this;
        }

        /**
         * Sets the maximum number of candidates to generate.
         * Higher values give more options but take longer.
         * Default: 50
         */

        public Builder maxCandidates(int max) {
            this.maxCandidates = Math.max(1, max);
            return this;
        }

        /**
         * Sets the pitch angle range in degrees.
         * Default: 5 to 85 degrees
         */

        public Builder pitchRangeDegrees(double min, double max) {
            this.minPitchDegrees = Math.max(0.1, min);
            this.maxPitchDegrees = Math.min(89.9, max);
            return this;
        }

        /**
         * Sets the velocity range in meters per second.
         * Default: 5 to 50 m/s
         */

        public Builder velocityRangeMps(double min, double max) {
            this.minVelocityMps = Math.max(0.1, min);
            this.maxVelocityMps = max;
            return this;
        }

        /**
         * Sets the angle step size for candidate generation.
         * Smaller values = more candidates, higher precision.
         * Default: 1.0 degrees (results in ~80 candidates max)
         */

        public Builder angleStepDegrees(double step) {
            this.angleStepDegrees = Math.max(0.1, step);
            return this;
        }

        /**
         * Sets the minimum arc height above the target.
         * This ensures the ball reaches a certain apex height before descending.
         * Higher values create more pronounced arcs that drop into the target.
         * Default: 0.0 (no minimum)
         * @param meters Minimum height above target that the trajectory apex must reach
         */

        public Builder minArcHeightMeters(double meters) {
            this.minArcHeightMeters = Math.max(0.0, meters);
            return this;
        }

        /**
         * Sets the minimum arc height above the target in feet.
         * @param feet Minimum height above target in feet
         */

        public Builder minArcHeightFeet(double feet) {
            this.minArcHeightMeters = Math.max(0.0, Units.feetToMeters(feet));
            return this;
        }

        /**
         * Adds a field obstacle for collision-aware trajectory solving.
         * When collision checking is enabled, trajectories that intersect obstacles
         * are rejected and the solver searches for clear paths.
         * 
         * @param obstacle The obstacle configuration
         */

        public Builder addObstacle(ObstacleConfig obstacle) {
            if (obstacle != null) {
                this.obstacles.add(obstacle);
                this.collisionCheckEnabled = true;
            }
            return this;
        }

        /**
         * Adds multiple obstacles at once.
         */

        public Builder obstacles(List<ObstacleConfig> obstacles) {
            if (obstacles != null) {
                this.obstacles.addAll(obstacles);
                if (!obstacles.isEmpty()) this.collisionCheckEnabled = true;
            }
            return this;
        }

        /**
         * Enables or disables collision checking against obstacles.
         * Auto-enabled when obstacles are added, but can be toggled.
         */

        public Builder collisionCheckEnabled(boolean enabled) {
            this.collisionCheckEnabled = enabled;
            return this;
        }

        /**
         * Sets the preferred arc height (soft bias, not a hard limit).
         * The solver will prefer trajectories with apex heights near this value.
         * Combined with arcBiasStrength to control how aggressively to prefer it.
         * 
         * Use this to encourage "up and over" shots without forcing extreme angles.
         * Set to 0 to disable arc preference.
         * 
         * @param meters Preferred trajectory apex height in meters
         */

        public Builder preferredArcHeightMeters(double meters) {
            this.preferredArcHeightMeters = Math.max(0.0, meters);
            return this;
        }

        /**
         * Sets the preferred arc height in feet.
         */

        public Builder preferredArcHeightFeet(double feet) {
            this.preferredArcHeightMeters = Math.max(0.0, Units.feetToMeters(feet));
            return this;
        }

        /**
         * Sets how strongly the solver prefers the preferred arc height.
         * 0.0 = no preference (ignore preferredArcHeight)
         * 0.5 = moderate bias (default)
         * 1.0 = strong bias toward preferred arc
         * 
         * @param strength Bias strength from 0.0 to 1.0
         */

        public Builder arcBiasStrength(double strength) {
            this.arcBiasStrength = Math.max(0.0, Math.min(1.0, strength));
            return this;
        }

        /**
         * Sets the lookup table for precomputed shots.
         */
        public Builder shotMap(ShotLookupTable map) {
            this.map = map;
            return this;
        }

        /**
         * Configures for fast solving with fewer candidates.
         */

        public Builder fastMode() {
            this.angleStepDegrees = 2.0;
            this.maxCandidates = 20;
            return this;
        }

        /**
         * Configures for high precision with more candidates.
         */

        public Builder precisionMode() {
            this.angleStepDegrees = 0.5;
            this.maxCandidates = 100;
            return this;
        }

        public ShotInput build() {
            return new ShotInput(
                shooterX, shooterY, shooterZ,
                shooterYaw,
                targetX, targetY, targetZ,
                targetRadius,
                robotVx, robotVy, robotOmegaRadPerSec, shooterRadiusMeters,
                includeAirResistance,
                shotPreference, maxCandidates,
                minPitchDegrees, maxPitchDegrees,
                minVelocityMps, maxVelocityMps,
                angleStepDegrees, minArcHeightMeters,
                obstacles, collisionCheckEnabled,
                preferredArcHeightMeters, arcBiasStrength,
                map
            );
        }
    }

    /** Creates a new builder for constructing a shot input. */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Creates a ShotInput for a stationary robot shooting at a target.
     * Convenience factory for the common case of no robot velocity and
     * default solver settings.
     *
     * @param shooterX  shooter X position (meters)
     * @param shooterY  shooter Y position (meters)
     * @param shooterZ  shooter height (meters)
     * @param targetX   target X position (meters)
     * @param targetY   target Y position (meters)
     * @param targetZ   target height (meters)
     * @param targetRadius target acceptance radius (meters)
     * @return a fully configured ShotInput
     */
    public static ShotInput stationary(double shooterX, double shooterY, double shooterZ,
                                        double targetX, double targetY, double targetZ,
                                        double targetRadius) {
        double yaw = Math.atan2(targetY - shooterY, targetX - shooterX);
        return builder()
                .shooterPositionMeters(shooterX, shooterY, shooterZ)
                .shooterYawRadians(yaw)
                .targetPositionMeters(targetX, targetY, targetZ)
                .targetRadiusMeters(targetRadius)
                .includeAirResistance(true)
                .build();
    }

    /**
     * Calculates horizontal (XY-plane) distance from shooter to target.
     *
     * @return horizontal distance in meters
     */
    public double getHorizontalDistanceMeters() {
        double dx = targetX - shooterX;
        double dy = targetY - shooterY;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Calculates 3D distance from shooter to target.
     */

    public double getTotalDistanceMeters() {
        double dx = targetX - shooterX;
        double dy = targetY - shooterY;
        double dz = targetZ - shooterZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /**
     * Calculates height difference (target - shooter).
     */

    public double getHeightDifferenceMeters() {
        return targetZ - shooterZ;
    }

    /**
     * Calculates required yaw to face target.
     */

    public double getRequiredYawRadians() {
        return Math.atan2(targetY - shooterY, targetX - shooterX);
    }

    /**
     * Calculates yaw adjustment needed from current shooter yaw.
     */

    public double getYawAdjustmentRadians() {
        double required = getRequiredYawRadians();
        double adjustment = required - shooterYaw;

        while (adjustment > Math.PI) adjustment -= 2 * Math.PI;
        while (adjustment < -Math.PI) adjustment += 2 * Math.PI;

        return adjustment;
    }

    public double getShooterX() { return shooterX; }
    public double getShooterY() { return shooterY; }
    public double getShooterZ() { return shooterZ; }
    public double getShooterYaw() { return shooterYaw; }
    public double getTargetX() { return targetX; }
    public double getTargetY() { return targetY; }
    public double getTargetZ() { return targetZ; }
    public double getTargetRadius() { return targetRadius; }
    public double getRobotVx() { return robotVx; }
    public double getRobotVy() { return robotVy; }
    
    /** Gets effective field-relative X velocity including tangential spin velocity */
    public double getEffectiveRobotVx() {
        return robotVx - robotOmegaRadPerSec * shooterRadiusMeters * Math.sin(shooterYaw);
    }
    
    /** Gets effective field-relative Y velocity including tangential spin velocity */
    public double getEffectiveRobotVy() {
        return robotVy + robotOmegaRadPerSec * shooterRadiusMeters * Math.cos(shooterYaw);
    }
    
    public double getRobotOmegaRadPerSec() { return robotOmegaRadPerSec; }
    public double getShooterRadiusMeters() { return shooterRadiusMeters; }
    public boolean isIncludeAirResistance() { return includeAirResistance; }

    public ShotPreference getShotPreference() { return shotPreference; }
    public int getMaxCandidates() { return maxCandidates; }
    public double getMinPitchDegrees() { return minPitchDegrees; }
    public double getMaxPitchDegrees() { return maxPitchDegrees; }
    public double getMinVelocityMps() { return minVelocityMps; }
    public double getMaxVelocityMps() { return maxVelocityMps; }
    public double getAngleStepDegrees() { return angleStepDegrees; }
    public double getMinArcHeightMeters() { return minArcHeightMeters; }

    public List<ObstacleConfig> getObstacles() { return obstacles; }
    public boolean isCollisionCheckEnabled() { return collisionCheckEnabled; }
    public double getPreferredArcHeightMeters() { return preferredArcHeightMeters; }
    public double getArcBiasStrength() { return arcBiasStrength; }

    /** Returns the precomputed shot map, if any. */
    public ShotLookupTable getMap() { return map; }

    /**
     * Whether any obstacle's footprint lies between shooter and target.
     * If true, the solver should strongly prefer high-arc solutions.
     */

    public boolean pathRequiresArc() {
        if (!collisionCheckEnabled || obstacles.isEmpty()) return false;
        for (ObstacleConfig obstacle : obstacles) {
            if (obstacle.pathCrossesObstacle(shooterX, shooterY, targetX, targetY)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the maximum clearance height needed across all obstacles.
     * The trajectory must arc above this height to avoid all obstacles.
     */

    public double getRequiredClearanceHeight() {
        double maxClearance = 0;
        if (!collisionCheckEnabled) return 0;
        for (ObstacleConfig obstacle : obstacles) {
            if (obstacle.isEnabled() && obstacle.pathCrossesObstacle(shooterX, shooterY, targetX, targetY)) {
                maxClearance = Math.max(maxClearance, obstacle.getClearanceHeight());
            }
        }
        return maxClearance;
    }

    @Override
    public String toString() {
        return String.format("Shot from (%.2f, %.2f, %.2f)m yaw=%.1f deg to (%.2f, %.2f, %.2f)m (%.2fm dist, %.2fm high) Robot V=(%.1f, %.1f)",
            shooterX, shooterY, shooterZ, Math.toDegrees(shooterYaw),
            targetX, targetY, targetZ,
            getHorizontalDistanceMeters(), getHeightDifferenceMeters(),
            robotVx, robotVy);
    }
}
