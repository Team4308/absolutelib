package ca.team4308.absolutelib.math.trajectories.shooter;

/**
 * Configuration for the hybrid shooter system.
 * 
 * <p>Immutable after construction. Use the builder to create instances.</p>
 * 
 * <h2>Configuration Hierarchy</h2>
 * <p>The system is split into two distinct configuration layers:</p>
 * <ul>
 *   <li><b>ShooterConfig (This Class):</b> Governs the <i>Mechanical/Electronic</i> hardware.
 *       Includes physical hard-stops, gear ratios, and conversion factors. Change these to match your robot's build.</li>
 *   <li><b>SolverConfig (TrajectorySolver):</b> Governs the <i>Physics &amp; Math</i> logic. 
 *       Includes simulation timesteps, search tolerances, and solve modes. Change these for performance or accuracy tuning.</li>
 * </ul>
 * 
 * <h2>Usage</h2>
 * <pre>{@code
 * ShooterConfig config = ShooterConfig.builder()
 *     .pitchLimits(30.0, 80.0)
 *     .rpmLimits(500, 6000)
 *     .rpmToVelocityFactor(0.00532)
 *     .maxDistanceMeters(12.0)
 *     .rpmFeedbackThreshold(50.0)
 *     .rpmAbortThreshold(500.0)
 *     .movingCompensationGain(1.0)
 *     .build();
 * }</pre>
 */
public final class ShooterConfig {

    private final double minPitchDegrees;
    private final double maxPitchDegrees;

    private final double minRpm;
    private final double maxRpm;

    private final double rpmToVelocityFactor;

    private final double minDistanceMeters;
    private final double maxDistanceMeters;

    private final double rpmFeedbackThreshold;
    private final double rpmAbortThreshold;
    private final double pitchCorrectionPerRpmDeficit;

    private final double movingCompensationGain;
    private final int movingIterations;

    private final double safetyMaxExitVelocity;
    private final double rpmDropRecoveryBoost;
    
    private final double systemLatencySeconds;
    private final double shooterRadiusMeters;

    private ShooterConfig(Builder b) {
        this.minPitchDegrees = b.minPitchDegrees;
        this.maxPitchDegrees = b.maxPitchDegrees;
        this.minRpm = b.minRpm;
        this.maxRpm = b.maxRpm;
        this.rpmToVelocityFactor = b.rpmToVelocityFactor;
        this.minDistanceMeters = b.minDistanceMeters;
        this.maxDistanceMeters = b.maxDistanceMeters;
        this.rpmFeedbackThreshold = b.rpmFeedbackThreshold;
        this.rpmAbortThreshold = b.rpmAbortThreshold;
        this.pitchCorrectionPerRpmDeficit = b.pitchCorrectionPerRpmDeficit;
        this.movingCompensationGain = b.movingCompensationGain;
        this.movingIterations = b.movingIterations;
        this.safetyMaxExitVelocity = b.safetyMaxExitVelocity;
        this.rpmDropRecoveryBoost = b.rpmDropRecoveryBoost;
        this.systemLatencySeconds = b.systemLatencySeconds;
        this.shooterRadiusMeters = b.shooterRadiusMeters;
    }

    public double getMinPitchDegrees() { return minPitchDegrees; }
    public double getMaxPitchDegrees() { return maxPitchDegrees; }
    public double getMinRpm() { return minRpm; }
    public double getMaxRpm() { return maxRpm; }
    public double getRpmToVelocityFactor() { return rpmToVelocityFactor; }
    public double getMinDistanceMeters() { return minDistanceMeters; }
    public double getMaxDistanceMeters() { return maxDistanceMeters; }
    public double getRpmFeedbackThreshold() { return rpmFeedbackThreshold; }
    public double getRpmAbortThreshold() { return rpmAbortThreshold; }
    public double getPitchCorrectionPerRpmDeficit() { return pitchCorrectionPerRpmDeficit; }
    public double getMovingCompensationGain() { return movingCompensationGain; }
    public int getMovingIterations() { return movingIterations; }
    public double getSafetyMaxExitVelocity() { return safetyMaxExitVelocity; }
    public double getRpmDropRecoveryBoost() { return rpmDropRecoveryBoost; }
    public double getSystemLatencySeconds() { return systemLatencySeconds; }
    public double getShooterRadiusMeters() { return shooterRadiusMeters; }

    /** Converts RPM to approximate exit velocity using the configured factor. */
    public double rpmToVelocity(double rpm) {
        return rpm * rpmToVelocityFactor;
    }

    /** Converts exit velocity back to approximate RPM using the configured factor. */
    public double velocityToRpm(double velocityMps) {
        return rpmToVelocityFactor > 0 ? velocityMps / rpmToVelocityFactor : 0;
    }

    /** Creates a new builder with sensible defaults. */
    public static Builder builder() {
        return new Builder();
    }

    /** Returns a pre-configured config suitable for a typical 2026 game shooter. */
    public static ShooterConfig defaults2026() {
        return builder()
                .pitchLimits(40.0, 82.0)
                .rpmLimits(500, 6000)
                .rpmToVelocityFactor(0.00532)
                .distanceLimits(0.5, 12.0)
                .rpmFeedbackThreshold(50.0)
                .rpmAbortThreshold(500.0)
                .pitchCorrectionPerRpmDeficit(0.005)
                .movingCompensationGain(1.0)
                .movingIterations(5)
                .safetyMaxExitVelocity(30.0)
                .rpmDropRecoveryBoost(0.0)
                .systemLatencySeconds(0.05)
                .shooterRadiusMeters(0.2)
                .build();
    }

    /** Creates a builder initialized with the values of this config. */
    public Builder toBuilder() {
        return new Builder()
                .pitchLimits(minPitchDegrees, maxPitchDegrees)
                .rpmLimits(minRpm, maxRpm)
                .rpmToVelocityFactor(rpmToVelocityFactor)
                .distanceLimits(minDistanceMeters, maxDistanceMeters)
                .rpmFeedbackThreshold(rpmFeedbackThreshold)
                .rpmAbortThreshold(rpmAbortThreshold)
                .pitchCorrectionPerRpmDeficit(pitchCorrectionPerRpmDeficit)
                .movingCompensationGain(movingCompensationGain)
                .movingIterations(movingIterations)
                .safetyMaxExitVelocity(safetyMaxExitVelocity)
                .rpmDropRecoveryBoost(rpmDropRecoveryBoost)
                .systemLatencySeconds(systemLatencySeconds)
                .shooterRadiusMeters(shooterRadiusMeters);
    }

    public static final class Builder {
        private double minPitchDegrees = 30.0;
        private double maxPitchDegrees = 82.0;
        private double minRpm = 0;
        private double maxRpm = 6000;
        private double rpmToVelocityFactor = 0.00532;
        private double minDistanceMeters = 0.5;
        private double maxDistanceMeters = 15.0;
        private double rpmFeedbackThreshold = 50.0;
        private double rpmAbortThreshold = 500.0;
        private double pitchCorrectionPerRpmDeficit = 0.005;
        private double movingCompensationGain = 1.0;
        private int movingIterations = 5;
        private double safetyMaxExitVelocity = 30.0;
        private double rpmDropRecoveryBoost = 0.0;
        private double systemLatencySeconds = 0.05;
        private double shooterRadiusMeters = 0.2;

        /** Set min and max pitch in degrees. */
        public Builder pitchLimits(double minDeg, double maxDeg) {
            this.minPitchDegrees = minDeg;
            this.maxPitchDegrees = maxDeg;
            return this;
        }

        /** Set min and max flywheel RPM. */
        public Builder rpmLimits(double min, double max) {
            this.minRpm = min;
            this.maxRpm = max;
            return this;
        }

        /** Factor to convert RPM → m/s exit velocity (default 0.00532 for 4-inch wheel). */
        public Builder rpmToVelocityFactor(double factor) {
            this.rpmToVelocityFactor = factor;
            return this;
        }

        /** Set min and max distance in meters. */
        public Builder distanceLimits(double minM, double maxM) {
            this.minDistanceMeters = minM;
            this.maxDistanceMeters = maxM;
            return this;
        }

        /** RPM deficit below which feedback correction kicks in. */
        public Builder rpmFeedbackThreshold(double threshold) {
            this.rpmFeedbackThreshold = threshold;
            return this;
        }

        /** RPM deficit above which shot is aborted instead of corrected. */
        public Builder rpmAbortThreshold(double threshold) {
            this.rpmAbortThreshold = threshold;
            return this;
        }

        /** Degrees of pitch correction per 1 RPM of deficit (linear correction). */
        public Builder pitchCorrectionPerRpmDeficit(double correction) {
            this.pitchCorrectionPerRpmDeficit = correction;
            return this;
        }

        /** Gain applied to robot velocity during moving compensation (1.0 = full). */
        public Builder movingCompensationGain(double gain) {
            this.movingCompensationGain = gain;
            return this;
        }

        /** Number of iterations for the iterative moving shot solver. */
        public Builder movingIterations(int iterations) {
            this.movingIterations = iterations;
            return this;
        }

        /** Maximum allowed exit velocity for safety validation. */
        public Builder safetyMaxExitVelocity(double maxMps) {
            this.safetyMaxExitVelocity = maxMps;
            return this;
        }

        /** Flat RPM boost applied to the final output to compensate for the wheels dropping speed upon ball contact. */
        public Builder rpmDropRecoveryBoost(double boostRpm) {
            this.rpmDropRecoveryBoost = boostRpm;
            return this;
        }

        /** System latency (feed time + spin-up) in seconds. */
        public Builder systemLatencySeconds(double latency) {
            this.systemLatencySeconds = latency;
            return this;
        }

        /** Distance from the robot's center of rotation to the shooter barrel in meters. */
        public Builder shooterRadiusMeters(double radius) {
            this.shooterRadiusMeters = radius;
            return this;
        }

        public ShooterConfig build() {
            return new ShooterConfig(this);
        }

        /**
         * Creates a builder from a DTO.
         */
        public static Builder fromDTO(ca.team4308.absolutelib.math.trajectories.network.TrajectoryConfigDTO dto) {
            return new Builder()
                .pitchLimits(dto.shooterPitchMin, dto.shooterPitchMax)
                .rpmLimits(dto.shooterRpmMin, dto.shooterRpmMax)
                .rpmToVelocityFactor(dto.shooterRpmToVelocityFactor)
                .distanceLimits(dto.shooterDistanceMin, dto.shooterDistanceMax)
                .rpmFeedbackThreshold(dto.shooterRpmFeedbackThreshold)
                .rpmAbortThreshold(dto.shooterRpmAbortThreshold)
                .pitchCorrectionPerRpmDeficit(dto.shooterPitchCorrectionPerRpm)
                .movingCompensationGain(dto.shooterMovingCompGain)
                .movingIterations(dto.shooterMovingIterations)
                .safetyMaxExitVelocity(dto.shooterSafetyMaxExitVel)
                .rpmDropRecoveryBoost(dto.shooterRpmDropRecovery);
        }
    }

    @Override
    public String toString() {
        return String.format("ShooterConfig[pitch=%.1f–%.1f°, rpm=%.0f–%.0f, dist=%.1f–%.1fm]",
                minPitchDegrees, maxPitchDegrees, minRpm, maxRpm, minDistanceMeters, maxDistanceMeters);
    }
}
